const Handlebars = require('hbs');
Handlebars.registerHelper("selectif", require('handlebars-helper-selectif'));